package com.discipline.complete;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
